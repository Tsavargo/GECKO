"""atomic-function-N demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-N processed: {data}")
    proxy.register("key-C", f"{data} -> N")
