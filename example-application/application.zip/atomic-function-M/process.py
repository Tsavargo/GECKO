"""atomic-function-M demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-M processed: {data}")
    proxy.register("key-E", f"{data} -> M")
