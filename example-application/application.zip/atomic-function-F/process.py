"""atomic-function-F demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-F processed: {data}")
    proxy.register("key-G", f"{data} -> F")
