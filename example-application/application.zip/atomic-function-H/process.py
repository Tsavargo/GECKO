"""atomic-function-H demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-H processed: {data}")
    proxy.register("key-I", f"{data} -> H")
