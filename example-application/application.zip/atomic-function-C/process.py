"""atomic-function-C demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-C processed: {data}")
    proxy.register("key-H", f"{data} -> C")
