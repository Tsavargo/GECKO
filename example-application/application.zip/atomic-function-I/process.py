"""atomic-function-I demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-I processed: {data}")
    proxy.register("key-B", f"{data} -> I")
