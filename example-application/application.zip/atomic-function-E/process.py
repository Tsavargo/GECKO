"""atomic-function-E demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-E processed: {data}")
    proxy.register("key-K", f"{data} -> E")
