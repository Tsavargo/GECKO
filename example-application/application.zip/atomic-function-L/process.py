"""atomic-function-L demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-L processed: {data}")
    proxy.register("key-O", f"{data} -> L")
