"""atomic-function-K demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-K processed: {data}")
    proxy.register("key-L", f"{data} -> K")
