"""atomic-function-P demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-P processed: {data}")
    proxy.register("finished", f"{data} -> P")
