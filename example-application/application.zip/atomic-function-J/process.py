"""atomic-function-J demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-J processed: {data}")
    proxy.register("key-N", f"{data} -> J")
