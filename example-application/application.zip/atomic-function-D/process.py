"""atomic-function-D demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-D processed: {data}")
    proxy.register("key-J", f"{data} -> D")
