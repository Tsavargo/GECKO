"""atomic-function-A demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-A processed: {data}")
    proxy.register("key-D", f"{data} -> A")
