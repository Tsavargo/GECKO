"""atomic-function-O demo: transforms data and chains it to the next function."""

from scheduler.proxy import Proxy


def process[Type](data: Type, proxy: Proxy) -> None:
    print(f"atomic-function-O processed: {data}")
    proxy.register("key-P", f"{data} -> O")
